import React from 'react';
import Article  from '../components/Articles';

class CSLGList extends React.Component{
    render(){
        return(
            <Article />

        )
    }
}

export default CSLGList;